from django.shortcuts import render, redirect
from apps.models import Tweet, Tweet_tag, Pid_tag
#from apps.serializers import Tweet, Tweet_tag, Pid_tag
#from models import *

# Create your views here.
def index(request):
    return render(request, 'index.html')


def Tweet(request):
    return render(request, 'tweet.html')