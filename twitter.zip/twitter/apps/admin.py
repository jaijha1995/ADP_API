from socket import fromshare
from django.contrib import admin
from apps.models import Re_like, Tweet
from apps.models import Tweet_tag
from apps.models import Pid_tag
from apps.models import Hashtag
from apps.models import Reply
from apps.models import Like
from apps.models import Answer
from apps.models import Re_like
from apps.models import Dislike
from apps.models import Re_Dislike





# Register your models here.

admin.site.register(Tweet)
admin.site.register(Tweet_tag)
admin.site.register(Pid_tag)
admin.site.register(Hashtag)
admin.site.register(Reply)
admin.site.register(Like)
admin.site.register(Answer)
admin.site.register(Re_like)
admin.site.register(Dislike)
admin.site.register(Re_Dislike)







