from asyncore import read
from django import views
from django.shortcuts import render, redirect, HttpResponse
from rest_framework import generics , mixins, viewsets
from apps import serializers
#from apps import mixins
from apps.models import Answer, Dislike, Like, Re_Dislike, Re_like, Reply, Tweet, Tweet_tag, Pid_tag
from apps.serializers import AnswerSerlializer, DislikeSerlizlizer,HashtagSerializer, LikeSerlializer, Re_DislikeSerlizlizer, Re_likeSerlializer,TweetSerializer, Tweet_tagSerializer, pid_tagSerializer, replySerlializer

class API_tweet(generics.ListCreateAPIView):
    queryset = Tweet.objects.all()
    serializer_class = TweetSerializer

class API_tweet_details(generics.RetrieveUpdateDestroyAPIView):
    queryset = Tweet.objects.all()
    serializer_class = TweetSerializer

class API_tweet_tag(generics.ListCreateAPIView):
    queryset = Tweet_tag.objects.all()
    serializer_class = Tweet_tagSerializer

class API_tweet_tag_details(generics.RetrieveUpdateDestroyAPIView):
    queryset = Tweet_tag.objects.all()
    serializer_class = Tweet_tagSerializer

class API_pid_tag(generics.ListCreateAPIView):
    queryset = Pid_tag.objects.all()
    serializer_class = pid_tagSerializer

class API_pid_tag_details(generics.RetrieveUpdateDestroyAPIView):
    queryset = Pid_tag.objects.all()
    serializer_class = pid_tagSerializer

class API_Hashtag(generics.ListCreateAPIView):
    queryset = Pid_tag.objects.all()
    serializer_class = HashtagSerializer

class API_Hashtag_details(generics.RetrieveUpdateDestroyAPIView):
    queryset = Pid_tag.objects.all()
    serializer_class = HashtagSerializer

class API_Reply(generics.ListCreateAPIView):
    queryset = Reply.objects.all()
    serializer_class = replySerlializer

class API_Reply_details(generics.RetrieveUpdateDestroyAPIView):
    queryset = Reply.objects.all()
    serializer_class = replySerlializer

class API_Like(generics.ListCreateAPIView):
    queryset = Like.objects.all()
    serializer_class = LikeSerlializer

class API_Like_details(generics.RetrieveUpdateDestroyAPIView):
    queryset = Like.objects.all()
    serializer_class = LikeSerlializer  

class API_Answer(generics.ListCreateAPIView):
    queryset = Answer.objects.all()
    serializer_class = AnswerSerlializer

class API_Answer_details(generics.RetrieveUpdateDestroyAPIView):
    queryset = Answer.objects.all()
    serializer_class = AnswerSerlializer

class API_Re_like(generics.ListCreateAPIView):
    queryset = Re_like.objects.all()
    serializer_class = Re_likeSerlializer

class API_Re_like_details(generics.RetrieveUpdateDestroyAPIView):
    queryset = Re_like.objects.all()
    serializer_class = Re_likeSerlializer

class API_Re_Dislike(generics.ListCreateAPIView):
    queryset = Re_Dislike.objects.all()
    serializer_class = Re_DislikeSerlizlizer

class API_Re_Dislike_details(generics.RetrieveUpdateDestroyAPIView):
    queryset = Re_Dislike.objects.all()
    serializer_class = Re_DislikeSerlizlizer

class API_Dislike(generics.ListCreateAPIView):
    queryset = Dislike.objects.all()
    serializer_class =  DislikeSerlizlizer

class API_Dislike_details(generics.RetrieveUpdateDestroyAPIView):
    queryset = Dislike.objects.all()
    serializer_class = DislikeSerlizlizer





