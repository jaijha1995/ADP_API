from dataclasses import fields
from lib2to3.pgen2.token import COMMENT
from pyexpat import model
from xml.etree.ElementTree import Comment
from rest_framework import serializers
from apps.models import Answer, Dislike, Like, Re_Dislike, Re_like, Reply, Tweet, Tweet_tag, Pid_tag, Hashtag


class TweetSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tweet
        fields = '__all__'

    extra_kwargs = {
		"all": {"required": False}
	}

class Tweet_tagSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tweet_tag
        fields = '__all__'


class pid_tagSerializer(serializers.ModelSerializer):
    class Meta:
        model =  Pid_tag
        fields = '__all__'

class HashtagSerializer(serializers.ModelSerializer):
    class Meta:
        model = Hashtag
        fields = '__all__'


class replySerlializer(serializers.ModelSerializer):
    class Meta:
        model = Reply
        fields = '__all__'


class LikeSerlializer(serializers.ModelSerializer):
    class Meta:
        model = Like
        fields =str('__all__')

class AnswerSerlializer(serializers.ModelSerializer):
    class Meta:
        model =  Answer
        fields = '__all__'

class Re_likeSerlializer(serializers.ModelSerializer):
    class Meta:
        model = Re_like
        fields = '__all__'

class Re_DislikeSerlizlizer(serializers.ModelSerializer):
    class Meta:
        model = Re_Dislike
        fields = '__all__'

class DislikeSerlizlizer(serializers.ModelSerializer):
    class Meta:
        model = Dislike
        fields = '__all__'


