# basic_api/urls.py
from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns
from apps import views


urlpatterns = [
    path('pid_tag/', views.API_pid_tag.as_view()),
    path('pid_tag/<int:pk>/', views.API_pid_tag_details.as_view()),
    path('tweet/', views.API_tweet.as_view()),
    path('tweet/<int:pk>/', views.API_tweet_details.as_view()),
    path('tweet_tag/', views.API_tweet_tag.as_view()),
    path('tweet_tag/<int:pk>/', views.API_tweet_tag_details.as_view()),
    path('hashtag/', views.API_Hashtag.as_view()),
    path('hashtag/<int:pk>/', views.API_Hashtag_details.as_view()),
    path('reply/', views.API_Reply.as_view()),
    path('reply/<int:pk>/', views.API_Reply_details.as_view()),
    path('like/', views.API_Like.as_view()),
    path('like/<int:pk>/', views.API_Like_details.as_view()),
    path('answer/', views.API_Answer.as_view()),
    path('answer/<int:pk>/', views.API_Answer_details.as_view()),
    path('relike/', views.API_Re_like.as_view()),
    path('relike/<int:pk>/', views.API_Re_like_details.as_view()),
    path('dislike',views.API_Dislike.as_view()),
    path('dislike.<int:pk>/', views.API_Dislike_details.as_view()),
    
]

urlpatterns = format_suffix_patterns(urlpatterns)