#from typing_extensions import self
from email.policy import default
from typing import Optional
from django.db import models
from django.contrib.auth.models import User

# Create your models here.


class Tweet(models.Model):
    user = models.CharField(max_length=50)
    ID = models.IntegerField()
    Pid_tag = models.CharField(max_length=100,default='')
    Tweet_tag  = models.CharField(max_length= 255, default='')
    hashtags = models.CharField(max_length=255, default='')
    video = models.FileField(upload_to= 'media',default='')
    image = models.ImageField(upload_to= 'media', default='')
    parent = models.CharField(max_length=100, default='')
    reply_to = models.CharField(max_length=255, default='')
    timestamp = models.DateTimeField()

    class Meta:
        db_table = "Tweet"

    def __str__(self):
        return self.user


class Like(models.Model):
    Like = models.ForeignKey(Tweet, on_delete=models.CASCADE)

    class Meta:
        db_table= "Like"

    def __str__(self):
        return str(self.Like)


class Tweet_tag(models.Model):
    ID  =models.IntegerField(default='')
    Tag_name = models.CharField(max_length=100)
    Number_of_tweet  =models.IntegerField()

    class Meta:
        db_table = "Tweet_tag"

    def __str__(self):
        return self.Tag_name

class Pid_tag(models.Model):
    ID = models.IntegerField()
    Pid_code = models.CharField(max_length=100)
    number_of_tweet = models.IntegerField()
    Hashtag = models.CharField(max_length=100, default='')

    class Meta:
        db_table = "Pid_tag"

    def __str__(self):
        return str(self.ID)

class Hashtag(models.Model):
    Hashtag = models.CharField(max_length=255, null=False)

    class Meta:
        db_table = "Hashtag"

    def __str__(self):
        return self.Hashtag

class Reply(models.Model):
    reply = models.ForeignKey(Tweet,on_delete=models.CASCADE)

    class Meta:
        db_table = "Reply"

    def __str__(self):
        return str(self.reply)

class Answer(models.Model):
    ans = models.CharField(max_length=255, default="")
    tag = models.ForeignKey(Hashtag, on_delete=models.CASCADE)

    class Meta:
        db_table = "Answer"

    def __str__(self):
        return self.ans

class Re_like(models.Model):
    Re_like = models.ForeignKey(Answer, on_delete=models.CASCADE)

    class Meta:
        db_table= "Re_like"

    def __str__(self):
        return str(self.Re_like)

class Re_Dislike(models.Model):
    Re_Dislike = models.ForeignKey(Answer, on_delete=models.CASCADE)

    class Meta:
        db_table = "Re_Dislike"

    def __str__(self):
        return str(self.Re_Dislike)

class Dislike(models.Model):
    Dislike = models.ForeignKey(Tweet, on_delete=models.CASCADE)

    class Meta:
        db_table = "Dislike"

    def __str__(self):
        return str(self.Dislike)













